package it.unina.adopt;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import javax.measure.converter.UnitConverter;
import javax.measure.quantity.Angle;
import javax.measure.quantity.Area;
import javax.measure.quantity.Length;
import javax.measure.unit.NonSI;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.interpolation.LinearInterpolator;
import org.apache.commons.math3.analysis.interpolation.UnivariateInterpolator;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.jscience.physics.amount.Amount;
import org.jscience.physics.amount.AmountFormat;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import processing.core.PVector;


public class MyAeroFuselage extends MyAeroComponent {

	private MyUtilities myUtilities;
	
	// Note: construction axes, 
	// X from FUSELAGE nose to tail,
	// Y from left wing to right wing,
	// Z from pilots feet to head 

	// view from left wing to right wing
	private List<Double> _outlineXZUpperCurveX = new ArrayList<Double>();
	private List<Double> _outlineXZUpperCurveZ = new ArrayList<Double>();

	// view from left wing to right wing
	private List<Double> _outlineXZLowerCurveX = new ArrayList<Double>();
	private List<Double> _outlineXZLowerCurveZ = new ArrayList<Double>();

	//	// Mesh XZ Upper Curve
	//	private List<Double> _meshXZCurveX = new ArrayList<Double>();
	//	private List<Double> _meshXZUpperCurveZ = new ArrayList<Double>();
	//	private List<Double> _meshXZLowerCurveZ = new ArrayList<Double>();

	// view from left wing to right wing
	private List<Double> _outlineXZCamberLineX = new ArrayList<Double>();
	private List<Double> _outlineXZCamberLineZ = new ArrayList<Double>();

	// view from top, right part of body
	private List<Double> _outlineXYSideRCurveX = new ArrayList<Double>();
	private List<Double> _outlineXYSideRCurveY = new ArrayList<Double>();
	private List<Double> _outlineXYSideRCurveZ = new ArrayList<Double>();
	// view from top, left part of body
	private List<Double> _outlineXYSideLCurveX = new ArrayList<Double>();
	private List<Double> _outlineXYSideLCurveY = new ArrayList<Double>();
	private List<Double> _outlineXYSideLCurveZ = new ArrayList<Double>();

	// view section Upper curve (fuselage front view, looking from -X towards +X)
	private List<Double> _sectionUpperCurveY = new ArrayList<Double>();
	private List<Double> _sectionUpperCurveZ = new ArrayList<Double>();

	// view section Lower curve (fuselage front view, looking from -X towards +X)
	private List<Double> _sectionLowerCurveY = new ArrayList<Double>();
	private List<Double> _sectionLowerCurveZ = new ArrayList<Double>();


	// EXPERIMENTAL
	//	// view section Upper curve (fuselage front view, looking from -X towards +X)
	//	public List<Double> _sectionUpperCurveY1 = new ArrayList<Double>();
	//	public List<Double> _sectionUpperCurveZ1 = new ArrayList<Double>();
	//
	//	// view section Lower curve (fuselage front view, looking from -X towards +X)
	//	public List<Double> _sectionLowerCurveY1 = new ArrayList<Double>();
	//	public List<Double> _sectionLowerCurveZ1 = new ArrayList<Double>();

	List<MyFuselageCurvesSection> _sectionsYZ = new ArrayList<MyFuselageCurvesSection>();
	public final int IDX_SECTION_YZ_NOSE_TIP   = 0;
	public final int IDX_SECTION_YZ_NOSE_CAP   = 1;
	public final int IDX_SECTION_YZ_MID_NOSE   = 2;
	public final int IDX_SECTION_YZ_CYLINDER_1 = 3;
	public final int IDX_SECTION_YZ_CYLINDER_2 = 4;
	public final int IDX_SECTION_YZ_MID_TAIL   = 5;
	public final int IDX_SECTION_YZ_TAIL_CAP   = 6;
	public final int IDX_SECTION_YZ_TAIL_TIP   = 7;
	public final int NUM_SECTIONS_YZ           = 8;
	List<Amount<Length> > _sectionsYZStations = new ArrayList<Amount<Length>>();

	List<List<Double>> _sectionUpperCurvesY = new ArrayList<List<Double>>();
	List<List<Double>> _sectionUpperCurvesZ = new ArrayList<List<Double>>();
	List<List<Double>> _sectionLowerCurvesY = new ArrayList<List<Double>>();
	List<List<Double>> _sectionLowerCurvesZ = new ArrayList<List<Double>>();

	//-----------------------------------------------------------------------
	// DESIGN PARAMETERS
	//-----------------------------------------------------------------------

	// Fuselage overall length
	//private Double _len_F, _len_F_MIN, _len_F_MAX;
	private Amount<Length> _len_F, _len_F_MIN,_len_F_MAX;

	// Fuselage nose length
	//private Double _len_N, _len_N_MIN, _len_N_MAX;
	private Amount<Length> _len_N, _len_N_MIN, _len_N_MAX;

	//private Double _len_C, _len_C_MIN, _len_C_MAX;
	private Amount<Length> _len_C, _len_C_MIN, _len_C_MAX;

	//private Double _len_T, _len_T_MIN, _len_T_MAX;
	private Amount<Length> _len_T, _len_T_MIN, _len_T_MAX;

	//private Double _len_N1, _len_N2, _len_N3;
	private Amount<Length> _len_N1, _len_N2, _len_N3;
	//private Double _diam_C,_diam_C_MIN , _diam_C_MAX ,_width_C;
	private Amount<Length> _diam_C,_diam_C_MIN , _diam_C_MAX;	

	//cylindrical section base area
	private double _area_C;

	//Wetted area estimate
	private Amount<Area> _sFront; // CANNOT FIND FUSELAGE HEIGHT in MyAeroFuselage!!
	private Amount<Area> _sWet; 

	//private Double _height_1;
	private Amount<Length> _height_1;

	//private Double _phi_1, _phi_2, _phi_3;
	private Amount<Angle> _phi_1, _phi_2, _phi_3;

	private Amount<Angle> _phi_N, _phi_T;
	private Amount<Length> _height_N,_height_N_MIN,_height_N_MAX, _height_T,_height_T_MIN,_height_T_MAX;

	private Amount<Length> _roughness;

	// Non-dimensional parameters
	private Double _lambda_F,_lambda_F_MIN,_lambda_F_MAX;
	private Double _lambda_N,_lambda_N_MIN,_lambda_N_MAX; 
	private Double _lambda_C,_lambda_C_MIN,_lambda_C_MAX;
	private Double _lambda_T,_lambda_T_MIN,_lambda_T_MAX;
	private Double _lenRatio_NF,_lenRatio_NF_MIN,_lenRatio_NF_MAX;
	private Double _lenRatio_CF,_lenRatio_CF_MIN,_lenRatio_CF_MAX;
	private Double _lenRatio_TF,_lenRatio_TF_MIN,_lenRatio_TF_MAX;
	private Double _formFactor;

	// Fuselage section parameters

	// Width and height
	private Amount<Length>  
	_sectionCylinderWidth, _sectionWidth_MIN, _sectionWidth_MAX;	

	private Amount<Length>  
	_dxNoseCap, _dxNoseCap_MIN, _dxNoseCap_MAX,
	_dxTailCap, _dxTailCap_MIN, _dxTailCap_MAX;

	// Non dimensional section parameters

	// how lower part is different from half diameter 
	private Double 
	_sectionCylinderLowerToTotalHeightRatio,
	_sectionLowerToTotalHeightRatio_MIN, _sectionLowerToTotalHeightRatio_MAX,
	_sectionNoseMidLowerToTotalHeightRatio,
	_sectionNoseMidToTotalHeightRatio_MIN, _sectionNoseMidToTotalHeightRatio_MAX,
	_sectionTailMidLowerToTotalHeightRatio,
	_sectionTailMidToTotalHeightRatio_MIN, _sectionTailMidToTotalHeightRatio_MAX;


	// shape index, 1 --> close to a rectangle; 0 --> close to a circle
	private Double 
	_sectionCylinderRhoUpper, _sectionRhoUpper_MIN, _sectionRhoUpper_MAX, 
	_sectionCylinderRhoLower, _sectionRhoLower_MIN, _sectionRhoLower_MAX,
	_sectionMidNoseRhoUpper,_sectionMidNoseRhoUpper_MIN,_sectionMidNoseRhoUpper_MAX,
	_sectionMidNoseRhoLower, _sectionMidNoseRhoLower_MIN,_sectionMidNoseRhoLower_MAX,
	_sectionMidTailRhoUpper,_sectionMidTailRhoUpper_MIN,_sectionMidTailRhoUpper_MAX,
	_sectionMidTailRhoLower, _sectionMidTailRhoLower_MIN,_sectionMidTailRhoLower_MAX;

	// meshing stuff
	private int _np_N = 10, _np_C = 4, _np_T = 10, _np_SecUp = 10, _np_SecLow = 10;
	private double _deltaXNose;
	private double _deltaXCylinder;
	private double _deltaXTail;
	protected Object mouseClicked;

	private MyFuselageAdjustCriteria _adjustCriterion = MyFuselageAdjustCriteria.NONE;

	// Constructor
	public MyAeroFuselage(String name, String description, double x, double y, double z) {

		super(name, description, x, y, z, MyAeroComponent.MAIN_BODY);

		// init variables - Reference aircraft: 
		AmountFormat.setInstance(AmountFormat.getExactDigitsInstance());

		_len_F_MIN     =  Amount.valueOf(10.0,SI.METRE);		
		_len_F_MAX     =  Amount.valueOf(40.0,SI.METRE);
		_len_F         =  Amount.valueOf(20.0,SI.METRE);

		_lenRatio_NF       = 0.15;
		_lenRatio_NF_MIN   = 0.1;
		_lenRatio_NF_MAX   = 0.15;

		_len_N         = Amount.valueOf( _lenRatio_NF * _len_F.doubleValue(SI.METRE), SI.METRE);
		_len_N_MIN     = Amount.valueOf(3.0, SI.METRE);
		_len_N_MAX     = Amount.valueOf( 8.0, SI.METRE);

		_lenRatio_CF       = 0.60;
		_lenRatio_CF_MIN   = 0.6;
		_lenRatio_CF_MAX   = 0.7;

		_len_C         = Amount.valueOf( _lenRatio_CF * _len_F.doubleValue(SI.METRE), SI.METRE);
		_len_C_MIN     = Amount.valueOf( 0.35 * _len_F_MIN.doubleValue(SI.METRE), SI.METRE);
		_len_C_MAX     = Amount.valueOf(0.75 * _len_F_MAX.doubleValue(SI.METRE), SI.METRE);

		_lenRatio_TF     = 1.0-_lenRatio_CF - _lenRatio_NF;
		_lenRatio_TF_MIN = 1.0-_lenRatio_CF_MIN - _lenRatio_NF_MIN;
		_lenRatio_TF_MAX = 1.0-_lenRatio_CF_MAX - _lenRatio_NF_MAX;

		_len_T         = Amount.valueOf( _lenRatio_TF * _len_F.doubleValue(SI.METRE), SI.METRE);
		_len_T_MIN     = Amount.valueOf( 2.0, SI.METRE);
		_len_T_MAX     = Amount.valueOf( 10.0, SI.METRE);

		_lambda_N      = 1.2; 
		_lambda_N_MIN  = 1.2;
		_lambda_N_MAX  = 2.5;

		_diam_C        = Amount.valueOf( _len_N.doubleValue(SI.METRE)/_lambda_N, SI.METRE);

		// Bounds to diameter value input
		_diam_C_MIN    = Amount.valueOf(2.0, SI.METRE);
		_diam_C_MAX    = Amount.valueOf( 7.0, SI.METRE);

		_lambda_C      = _len_C.doubleValue(SI.METRE)/_diam_C.doubleValue(SI.METRE); // _len_C / _diam_C;
		_lambda_C_MIN  = 3.0;
		_lambda_C_MAX  = 7.0;

		_lambda_T      = _len_T.doubleValue(SI.METRE)/_diam_C.doubleValue(SI.METRE); // _len_T / _diam_C; // (_len_F - _len_N - _len_C) / _diam_C
		_lambda_T_MIN  = 2.8;
		_lambda_T_MAX  = 3.2;

		_lambda_F      = _len_F.doubleValue(SI.METRE)/_diam_C.doubleValue(SI.METRE); // _len_F/_diam_C;
		_lambda_F_MIN  = 8.0;
		_lambda_F_MAX  = 12.5;

		_height_1      = Amount.valueOf( 0.0, SI.METRE);

		// Fuselage Roughness
		_roughness = Amount.valueOf(0.405 * Math.pow(10,-5), SI.METRE);

		// positive if nose tip higher than cylindrical part ref. line (in XZ plane)
		_height_N      = Amount.valueOf(-0.15*_diam_C.doubleValue(SI.METRE), SI.METRE);
		_height_N_MIN  =(Amount.valueOf( -0.2 *_diam_C.doubleValue(SI.METRE), SI.METRE));
		_height_N_MAX  =(Amount.valueOf( 0.2 *_diam_C.doubleValue(SI.METRE), SI.METRE));
		_height_T      = Amount.valueOf(  0.8*(0.5*_diam_C.doubleValue(SI.METRE)), SI.METRE);
		_height_T_MIN  =(Amount.valueOf(  0.4*(0.5*_diam_C.doubleValue(SI.METRE)), SI.METRE));
		_height_T_MAX  =(Amount.valueOf(  1.0*(0.5*_diam_C.doubleValue(SI.METRE)), SI.METRE));
		_phi_N         = Amount.valueOf( 
				Math.atan(
						(_diam_C.doubleValue(SI.METRE) - _height_N.doubleValue(SI.METRE))
						/ _len_N.doubleValue(SI.METRE)
						), 
						SI.RADIAN);

		// Section parameters

		_sectionCylinderWidth     = Amount.valueOf(3.5,SI.METRE);
		_sectionWidth_MIN         = Amount.valueOf(0.7*_diam_C_MIN.doubleValue(SI.METRE), SI.METRE);
		_sectionWidth_MAX         = Amount.valueOf(1.3*_diam_C_MAX.doubleValue(SI.METRE), SI.METRE);

		_dxNoseCap                = Amount.valueOf(0.050 * _len_N.doubleValue(SI.METRE), SI.METRE);
		_dxNoseCap_MIN            = Amount.valueOf(0.015 * _len_N.doubleValue(SI.METRE), SI.METRE);
		_dxNoseCap_MAX            = Amount.valueOf(0.0150* _len_N.doubleValue(SI.METRE), SI.METRE);

		_dxTailCap                = Amount.valueOf(0.050*_len_T.doubleValue(SI.METRE), SI.METRE);
		_dxTailCap_MIN            = Amount.valueOf(0.000*_len_T.doubleValue(SI.METRE), SI.METRE);
		_dxTailCap_MAX            = Amount.valueOf(0.100*_len_T.doubleValue(SI.METRE), SI.METRE);

		//_hB=_diam_C //new LengthAmount(5,SI.METRE);
		_sectionCylinderLowerToTotalHeightRatio     = 0.4;
		_sectionNoseMidLowerToTotalHeightRatio      = _sectionCylinderLowerToTotalHeightRatio;
		_sectionTailMidLowerToTotalHeightRatio      = _sectionCylinderLowerToTotalHeightRatio;
		//++++++++++++++++++++++++++++++++++++
		_sectionLowerToTotalHeightRatio_MIN = 0.1;
		_sectionLowerToTotalHeightRatio_MAX = 0.5;
		_sectionNoseMidToTotalHeightRatio_MIN       = _sectionLowerToTotalHeightRatio_MIN;
		_sectionNoseMidToTotalHeightRatio_MAX       = _sectionLowerToTotalHeightRatio_MAX;
		_sectionTailMidToTotalHeightRatio_MIN       = _sectionLowerToTotalHeightRatio_MIN;
		_sectionTailMidToTotalHeightRatio_MAX       = _sectionLowerToTotalHeightRatio_MAX;

		//+++++++++++++++++++++++++++++++++++++
		_sectionCylinderRhoUpper     = 0.2;
		_sectionRhoUpper_MIN = 0.0;
		_sectionRhoUpper_MAX = 1.0;
		_sectionMidNoseRhoUpper      = _sectionCylinderRhoUpper;
		_sectionMidNoseRhoUpper_MIN  = _sectionRhoUpper_MIN;
		_sectionMidNoseRhoUpper_MAX  = _sectionRhoUpper_MAX;
		_sectionMidTailRhoUpper      = _sectionCylinderRhoUpper;
		_sectionMidTailRhoUpper_MIN  = _sectionRhoUpper_MIN;
		_sectionMidTailRhoUpper_MAX  = _sectionRhoUpper_MAX;

		//+++++++++++++++++++++++++++++++++++++
		_sectionCylinderRhoLower     =  0.3;
		_sectionRhoLower_MIN = 0.0;
		_sectionRhoLower_MAX = 1.0;
		_sectionMidNoseRhoLower      = _sectionCylinderRhoLower;
		_sectionMidNoseRhoLower_MIN  = _sectionRhoLower_MIN;
		_sectionMidNoseRhoLower_MAX  = _sectionRhoLower_MAX;
		_sectionMidTailRhoLower      = _sectionCylinderRhoLower;
		_sectionMidTailRhoLower_MIN  = _sectionRhoLower_MIN;
		_sectionMidTailRhoLower_MAX  = _sectionRhoLower_MAX;

		//		// mesh stuff
		//		_deltaXNose     = _len_N.doubleValue(SI.METRE)/(_np_N-1);
		//		_deltaXCylinder = _len_C.doubleValue(SI.METRE)/(_np_C-1);
		//		_deltaXTail     = _len_T.doubleValue(SI.METRE)/(_np_T-1);

		// make all calculations
		calculateOutlines(
				10, // num. points Nose
				4,  // num. points Cylinder
				10, // num. points Tail
				10, // num. points Upper section
				10  // num. points Lower section
				);

	
