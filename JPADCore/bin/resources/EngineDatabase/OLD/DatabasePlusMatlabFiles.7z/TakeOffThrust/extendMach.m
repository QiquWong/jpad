function f = extendMach(mach,y)

% y(end)
% xx = linspace(mach(end),1,11)';
% spl = pchip([mach; xx(2:end)], [y; y(end)*ones(10,1)]);
% f = ppval(spl, myMach);

xx1 = linspace(0,max(mach),50);
% xx2 = linspace(xx1(end),1,11);

spl = pchip(mach, y);
f = [ppval(spl, xx1), ppval(spl, xx1(end))*ones(1,10)];
spl2 = pchip([xx1(1:end-1), linspace(xx1(end),0.6,11)], f);
f = ppval(spl2, linspace(0,0.6,60));
f = f(:);